//Group 12:deliver System 
//Twizeyimana onesphore 223008132
//Murekatete kellen 223008892
//Munezero enock 223024831
package com.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DB {

public static Connection getConnection()throws Exception{
	
	Class.forName("com.mysql.cj.jdbc.Driver");
	
	return DriverManager.getConnection("jdbc:mysql://localhost:3306/DeliverSystemDB","root","");
}

}
