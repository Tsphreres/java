//Group 12:deliver System 
//Twizeyimana onesphore 223008132
//Murekatete kellen 223008892
//Munezero enock 223024831
package com.form;

import java.awt.BorderLayout;

import javax.swing.*;

import com.panel.*;

public class SMIS extends JFrame{
	JTabbedPane tabs=new JTabbedPane();
	
	//constructor
	
	public SMIS(String role, int userid){
		setTitle("=====Deliver System====" +
				"");
		setSize(900,600);
		setLayout(new BorderLayout());
		if(role.equalsIgnoreCase("admin")){
			tabs.add("users",new UserPanel());
			tabs.add("command",new Commandpanel());
			tabs.add("customers",new customerspanel(null));
			tabs.add("deliver",new DeliveryPanel(null));
			
			
		}
		
		else if(role.equalsIgnoreCase("deliver")){
			tabs.add("command",new Commandpanel());
			tabs.add("deliver",new DeliveryPanel(null));
			
		}
		else if(role.equalsIgnoreCase("customers")){
			tabs.add("see the list of command",new Commandpanel ());
		}
		add(tabs,BorderLayout.CENTER);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	
	
	
}
}
