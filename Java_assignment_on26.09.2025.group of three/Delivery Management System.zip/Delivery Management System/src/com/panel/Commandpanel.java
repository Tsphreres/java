//Group 12:deliver System 
//Twizeyimana onesphore 223008132
//Murekatete kellen 223008892
//Munezero enock 223024831
package com.panel;

import com.util.DB;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Commandpanel extends JPanel implements ActionListener {

    private JTextField nameTxt, categoryTxt, locationTxt, priceTxt;
    private JButton addBtn, updateBtn, deleteBtn, loadBtn;
    private JTable table;
    private DefaultTableModel model;
    private JFrame parentFrame;
    
    // Navigation buttons
    private JButton commondBtn, customerBtn, deliverBtn, userBtn;

    public Commandpanel(JFrame parentFrame) {
        this.parentFrame = parentFrame;
        setLayout(null);
        setBackground(Color.WHITE);
        createNavigationBar();
        initializeComponents();
        loadCommands(); // Load data automatically when panel opens
    }

    public Commandpanel() {
		// TODO Auto-generated constructor stub
	}

	private void initializeComponents() {
        // Fields
        nameTxt = new JTextField();
        categoryTxt = new JTextField();
        locationTxt = new JTextField();
        priceTxt = new JTextField();

        // Buttons
        addBtn = new JButton("Add Command");
        updateBtn = new JButton("Update Command");
        deleteBtn = new JButton("Delete Command");
        loadBtn = new JButton("Refresh");
      

        // Table
        String[] labels = {"Command Name", "Category", "Location to Deliver", "Price (RWF)"};
        model = new DefaultTableModel(labels, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table non-editable
            }
        };
        table = new JTable(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                selectCommandFromTable();
            }
        });
        
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(20, 250, 750, 250);
        add(sp);

        // Layout fields
        int y = 80;
        addField("Command Name", nameTxt, y); y += 35;
        addField("Category", categoryTxt, y); y += 35;
        addField("Location", locationTxt, y); y += 35;
        addField("Price (RWF)", priceTxt, y); y += 35;

        // Buttons
        addButtons();
    }

    private void createNavigationBar() {
        // Create navigation panel
        JPanel navPanel = new JPanel();
        navPanel.setBounds(0, 0, 800, 40);
        navPanel.setBackground(Color.DARK_GRAY);
        navPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        
        // Create navigation buttons
        commondBtn = new JButton("Commands");
        customerBtn = new JButton("Customers");
        deliverBtn = new JButton("Delivery");
        userBtn = new JButton("Users");
        
        // Style the active button differently
        commondBtn.setBackground(Color.BLUE);
        commondBtn.setForeground(Color.WHITE);
        commondBtn.setFont(new Font("Arial", Font.BOLD, 12));
        
        // Style other buttons
        Color inactiveColor = new Color(200, 200, 200);
        customerBtn.setBackground(inactiveColor);
        deliverBtn.setBackground(inactiveColor);
        userBtn.setBackground(inactiveColor);
        
        // Add action listeners
        commondBtn.addActionListener(this);
        customerBtn.addActionListener(this);
        deliverBtn.addActionListener(this);
        userBtn.addActionListener(this);
        
        // Add buttons to navigation panel
        navPanel.add(commondBtn);
        navPanel.add(customerBtn);
        navPanel.add(deliverBtn);
        navPanel.add(userBtn);
        
        add(navPanel);
    }

    private void addField(String lbl, JComponent txt, int y) {
        JLabel l = new JLabel(lbl);
        l.setBounds(20, y, 120, 25);
        l.setFont(new Font("Arial", Font.BOLD, 12));
        txt.setBounds(150, y, 200, 30);
        txt.setFont(new Font("Arial", Font.PLAIN, 12));
        add(l);
        add(txt);
    }

    private void addButtons() {
        int x = 400;
        int y = 80;
        int width = 150;
        int height = 35;
        
        addBtn.setBounds(x, y, width, height);
        updateBtn.setBounds(x, y + 40, width, height);
        deleteBtn.setBounds(x, y + 80, width, height);
        loadBtn.setBounds(x, y + 120, width, height);
       
        // Style buttons
        Color buttonColor = new Color(70, 130, 180);
        Color buttonTextColor = Color.WHITE;
        
        styleButton(addBtn, buttonColor, buttonTextColor);
        styleButton(updateBtn, buttonColor, buttonTextColor);
        styleButton(deleteBtn, new Color(220, 80, 60), buttonTextColor);
        styleButton(loadBtn, new Color(60, 160, 60), buttonTextColor);
       

        add(addBtn);
        add(updateBtn);
        add(deleteBtn);
        add(loadBtn);
       

        addBtn.addActionListener(this);
        updateBtn.addActionListener(this);
        deleteBtn.addActionListener(this);
        loadBtn.addActionListener(this);
      
    }
    
    private void styleButton(JButton button, Color bgColor, Color textColor) {
        button.setBackground(bgColor);
        button.setForeground(textColor);
        button.setFont(new Font("Arial", Font.BOLD, 12));
        button.setFocusPainted(false);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // Handle navigation button clicks first
        if (e.getSource() == deliverBtn) {
            switchToPanel("Delivery");
            return;
        } else if (e.getSource() == commondBtn) {
            switchToPanel("Commond");
            return;
        } else if (e.getSource() == customerBtn) {
            switchToPanel("Customer");
            return;
        } else if (e.getSource() == userBtn) {
            switchToPanel("User");
            return;
        }

        // Handle command operations
        try {
            if (e.getSource() == addBtn) {
                addCommand();
            } else if (e.getSource() == updateBtn) {
                updateCommand();
            } else if (e.getSource() == deleteBtn) {
                deleteCommand();
            } else if (e.getSource() == loadBtn) {
                loadCommands();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addCommand() throws Exception {
        if (validateFields()) {
            try (Connection con = DB.getConnection()) {
                // Check for duplicates
                String checkSql = "SELECT * FROM commands WHERE command_name=?";
                PreparedStatement checkPs = con.prepareStatement(checkSql);
                checkPs.setString(1, nameTxt.getText().trim());
                ResultSet rs = checkPs.executeQuery();

                if (rs.next()) {
                    JOptionPane.showMessageDialog(this,
                            "⚠ Command name already exists!",
                            "Duplicate Error",
                            JOptionPane.WARNING_MESSAGE);
                } else {
                    String sql = "INSERT INTO commands (command_name, category, location_to_deliver, price_RWF) VALUES (?, ?, ?, ?)";
                    PreparedStatement ps = con.prepareStatement(sql);
                    ps.setString(1, nameTxt.getText().trim());
                    ps.setString(2, categoryTxt.getText().trim());
                    ps.setString(3, locationTxt.getText().trim());
                    ps.setDouble(4, Double.parseDouble(priceTxt.getText().trim()));
                    
                    int rowsAffected = ps.executeUpdate();
                    if (rowsAffected > 0) {
                        JOptionPane.showMessageDialog(this, "Command added successfully!");
                        clearFields();
                        loadCommands();
                    }
                }
            }
        }
    }

    private void updateCommand() throws Exception {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a command to update from the table.");
            return;
        }
        
        if (validateFields()) {
            try (Connection con = DB.getConnection()) {
                String commandName = (String) model.getValueAt(selectedRow, 0);
                String sql = "UPDATE commands SET command_name=?, category=?, location_to_deliver=?, price_RWF=? WHERE command_name=?";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, nameTxt.getText().trim());
                ps.setString(2, categoryTxt.getText().trim());
                ps.setString(3, locationTxt.getText().trim());
                ps.setDouble(4, Double.parseDouble(priceTxt.getText().trim()));
                ps.setString(5, commandName);
                
                int rowsAffected = ps.executeUpdate();
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Command updated successfully!");
                    clearFields();
                    loadCommands();
                }
            }
        }
    }

    private void deleteCommand() throws Exception {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a command to delete from the table.");
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Are you sure you want to delete this command?", 
            "Confirm Delete", 
            JOptionPane.YES_NO_OPTION);
            
        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection con = DB.getConnection()) {
                String commandName = (String) model.getValueAt(selectedRow, 0);
                String sql = "DELETE FROM commands WHERE command_name=?";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, commandName);
                
                int rowsAffected = ps.executeUpdate();
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Command deleted successfully!");
                    clearFields();
                    loadCommands();
                }
            }
        }
    }

    private void loadCommands() {
        try (Connection con = DB.getConnection()) {
            model.setRowCount(0);
            String sql = "SELECT command_name, category, location_to_deliver, price_RWF FROM commands ORDER BY command_name";
            ResultSet rs = con.createStatement().executeQuery(sql);
            
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("command_name"),
                    rs.getString("category"),
                    rs.getString("location_to_deliver"),
                    String.format("%,.0f RWF", rs.getDouble("price_RWF"))
                });
            }
            
            if (model.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "No commands found in the database.");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading commands: " + ex.getMessage());
        }
    }

    private void selectCommandFromTable() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow >= 0) {
            nameTxt.setText(model.getValueAt(selectedRow, 0).toString());
            categoryTxt.setText(model.getValueAt(selectedRow, 1).toString());
            locationTxt.setText(model.getValueAt(selectedRow, 2).toString());
            
            // Remove "RWF" and formatting from price for editing
            String price = model.getValueAt(selectedRow, 3).toString().replace("RWF", "").replace(",", "").trim();
            priceTxt.setText(price);
        }
    }

    private boolean validateFields() {
        if (nameTxt.getText().trim().isEmpty() ||
            categoryTxt.getText().trim().isEmpty() ||
            locationTxt.getText().trim().isEmpty() ||
            priceTxt.getText().trim().isEmpty()) {
            
            JOptionPane.showMessageDialog(this, 
                "Please fill in all fields.", 
                "Validation Error", 
                JOptionPane.WARNING_MESSAGE);
            return false;
        }
        
        try {
            double price = Double.parseDouble(priceTxt.getText().trim());
            if (price < 0) {
                JOptionPane.showMessageDialog(this, 
                    "Price must be a positive number.", 
                    "Validation Error", 
                    JOptionPane.WARNING_MESSAGE);
                return false;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, 
                "Please enter a valid number for price.", 
                "Validation Error", 
                JOptionPane.WARNING_MESSAGE);
            return false;
        }
        
        return true;
    }

    private void clearFields() {
        nameTxt.setText("");
        categoryTxt.setText("");
        locationTxt.setText("");
        priceTxt.setText("");
        table.clearSelection();
    }

    private void switchToPanel(String panelName) {
        if (parentFrame == null) return;

        parentFrame.getContentPane().removeAll();
        JPanel newPanel;

        switch (panelName.toLowerCase()) {
            case "delivery":
                newPanel = new DeliveryPanel(parentFrame);
                break;
            case "commond":
                newPanel = new Commandpanel(parentFrame);
                break;
            case "customer":
                newPanel = new CustomerPanel(parentFrame);
                break;
            case "user":
                newPanel = new UserPanel(parentFrame);
                break;
            default:
                newPanel = new Commandpanel(parentFrame);
                break;
        }

        parentFrame.add(newPanel);
        parentFrame.revalidate();
        parentFrame.repaint();
    }

    // Update your UserPanel to include proper navigation
    public static class UserPanel extends JPanel {
        public UserPanel(JFrame parent) {
            setLayout(new BorderLayout());
            add(new JLabel("User Management Panel", SwingConstants.CENTER));
            // Add your user management components here
        }
    }

    public static class DeliveryPanel extends JPanel {
        public DeliveryPanel(JFrame parent) {
            setLayout(new BorderLayout());
            add(new JLabel("Delivery Management Panel", SwingConstants.CENTER));
        }
    }

    public static class CustomerPanel extends JPanel {
        public CustomerPanel(JFrame parent) {
            setLayout(new BorderLayout());
            add(new JLabel("Customer Management Panel", SwingConstants.CENTER));
        }
    }

    public static void main(String[] args) {
        // Test the CommondPanel independently
        JFrame frame = new JFrame("Commands Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 550);
        frame.add(new Commandpanel(frame));
        frame.setVisible(true);
    }
}