//Group 12:deliver System 
//Twizeyimana onesphore 223008132
//Murekatete kellen 223008892
//Munezero enock 223024831
package com.panel;

import com.util.DB;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class UserPanel extends JPanel implements ActionListener {

    private JTextField idTxt, nameTxt, phoneTxt, emailTxt;
    private JPasswordField passTxt;
    private JComboBox<String> roleComboBox;
    private JButton addBtn, updateBtn, deleteBtn, loadBtn;
    private JTable table;
    private DefaultTableModel model;
    
    // Navigation buttons
    private JButton commondBtn, customerBtn, deliverBtn, userBtn;
    private JFrame parentFrame;

    public UserPanel(JFrame parentFrame) {
        this.parentFrame = parentFrame;
        setLayout(null);
        createNavigationBar();
        initializeComponents();
    }

    public UserPanel() {
        this(null);
    }

    private void initializeComponents() {
        // Fields
        idTxt = new JTextField();
        nameTxt = new JTextField();
        phoneTxt = new JTextField();
        emailTxt = new JTextField();
        passTxt = new JPasswordField();
        
        // Role ComboBox with predefined options
        String[] roles = {"admin", "deliver", "customer"};
        roleComboBox = new JComboBox<>(roles);
        roleComboBox.setSelectedIndex(0); // Set default to "admin"

        // Buttons
        addBtn = new JButton("Add");
        updateBtn = new JButton("Update");
        deleteBtn = new JButton("Delete");
        loadBtn = new JButton("Load");

        // Table
        String[] labels = {"ID", "Username", "Password", "Phone", "Email", "Role"};
        model = new DefaultTableModel(labels, 0);
        table = new JTable(model);
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(20, 250, 750, 200);
        add(sp);

        // Layout fields
        int y = 80;
        addField("ID", idTxt, y); y += 30;
        addField("Username", nameTxt, y); y += 30;
        addField("Password", passTxt, y); y += 30;
        addField("Phone", phoneTxt, y); y += 30;
        addField("Email", emailTxt, y); y += 30;
        addComboField("Role", roleComboBox, y); y += 30;

        // Buttons
        addButtons();
    }

    private void createNavigationBar() {
        // Create navigation panel
        JPanel navPanel = new JPanel();
        navPanel.setBounds(0, 0, 800, 40);
        navPanel.setBackground(Color.black);
        navPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        
        // Create navigation buttons
        commondBtn = new JButton("Commond");
        customerBtn = new JButton("Customer");
        deliverBtn = new JButton("Delivery");
        userBtn = new JButton("Users");
        
        // Style the active button differently
        userBtn.setBackground(Color.BLUE);
        userBtn.setForeground(Color.WHITE);
        
        // Add action listeners
        commondBtn.addActionListener(this);
        customerBtn.addActionListener(this);
        deliverBtn.addActionListener(this);
        userBtn.addActionListener(this);
        
        // Add buttons to navigation panel
        navPanel.add(commondBtn);
        navPanel.add(customerBtn);
        navPanel.add(deliverBtn);
        navPanel.add(userBtn);
        
        add(navPanel);
    }

    private void addField(String lbl, JComponent txt, int y) {
        JLabel l = new JLabel(lbl);
        l.setBounds(20, y, 80, 25);
        txt.setBounds(100, y, 150, 25);
        add(l);
        add(txt);
    }

    private void addComboField(String lbl, JComboBox<String> combo, int y) {
        JLabel l = new JLabel(lbl);
        l.setBounds(20, y, 80, 25);
        combo.setBounds(100, y, 150, 25);
        add(l);
        add(combo);
    }

    private void addButtons() {
        addBtn.setBounds(300, 80, 100, 30);
        updateBtn.setBounds(300, 120, 100, 30);
        deleteBtn.setBounds(300, 160, 100, 30);
        loadBtn.setBounds(300, 200, 100, 30);

        add(addBtn);
        add(updateBtn);
        add(deleteBtn);
        add(loadBtn);

        addBtn.addActionListener(this);
        updateBtn.addActionListener(this);
        deleteBtn.addActionListener(this);
        loadBtn.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // Handle navigation button clicks first
        if (e.getSource() == deliverBtn) {
            switchToPanel("Delivery");
            return;
        } else if (e.getSource() == commondBtn) {
            switchToPanel("Commond");
            return;
        } else if (e.getSource() == customerBtn) {
            switchToPanel("Customer");
            return;
        } else if (e.getSource() == userBtn) {
            switchToPanel("User");
            return;
        }

        // Existing database operations
        handleDatabaseOperations(e);
    }

    private void handleDatabaseOperations(ActionEvent e) {
        try (Connection con = DB.getConnection()) {
            if (e.getSource() == addBtn) {
                addUser(con);
            } else if (e.getSource() == updateBtn) {
                updateUser(con);
            } else if (e.getSource() == deleteBtn) {
                deleteUser(con);
            } else if (e.getSource() == loadBtn) {
                loadUsers(con);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, " Error: " + ex.getMessage());
        }
    }

    private void addUser(Connection con) throws SQLException {
        String checkSql = "SELECT * FROM user WHERE username=?";
        PreparedStatement checkPs = con.prepareStatement(checkSql);
        checkPs.setString(1, nameTxt.getText());
        ResultSet rs = checkPs.executeQuery();

        if (rs.next()) {
            JOptionPane.showMessageDialog(this,
                    "⚠ Username already exists!",
                    "Duplicate Error",
                    JOptionPane.WARNING_MESSAGE);
        } else {
            String sql = "INSERT INTO `user`(username, password, phone, email, role) VALUES(?,?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, nameTxt.getText());
            ps.setString(2, new String(passTxt.getPassword()));
            ps.setString(3, phoneTxt.getText());
            ps.setString(4, emailTxt.getText());
            ps.setString(5, roleComboBox.getSelectedItem().toString());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, " User added successfully!");
            clearFields();
        }
    }

    private void updateUser(Connection con) throws SQLException {
        if (idTxt.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please select a user to update from the table.");
            return;
        }
        
        String sql = "UPDATE user SET username=?, password=?, phone=?, email=?, role=? WHERE userid=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, nameTxt.getText());
        ps.setString(2, new String(passTxt.getPassword()));
        ps.setString(3, phoneTxt.getText());
        ps.setString(4, emailTxt.getText());
        ps.setString(5, roleComboBox.getSelectedItem().toString());
        ps.setInt(6, Integer.parseInt(idTxt.getText()));
        ps.executeUpdate();
        JOptionPane.showMessageDialog(this, " User updated successfully!");
        clearFields();
    }

    private void deleteUser(Connection con) throws SQLException {
        if (idTxt.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please select a user to delete from the table.");
            return;
        }
        
        String sql = "DELETE FROM user WHERE userid=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1, Integer.parseInt(idTxt.getText()));
        ps.executeUpdate();
        JOptionPane.showMessageDialog(this, " User deleted successfully!");
        clearFields();
    }

    private void loadUsers(Connection con) throws SQLException {
        model.setRowCount(0);
        String sql = "SELECT * FROM user";
        ResultSet rs = con.createStatement().executeQuery(sql);
        while (rs.next()) {
            model.addRow(new Object[]{
                    rs.getInt("userid"),
                    rs.getString("username"),
                    rs.getString("password"),
                    rs.getString("phone"),
                    rs.getString("email"),
                    rs.getString("role")
            });
        }
        
        // Add mouse listener to table for row selection
        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow >= 0) {
                    idTxt.setText(model.getValueAt(selectedRow, 0).toString());
                    nameTxt.setText(model.getValueAt(selectedRow, 1).toString());
                    passTxt.setText(model.getValueAt(selectedRow, 2).toString());
                    phoneTxt.setText(model.getValueAt(selectedRow, 3).toString());
                    emailTxt.setText(model.getValueAt(selectedRow, 4).toString());
                    
                    // Set the role in combobox
                    String role = model.getValueAt(selectedRow, 5).toString();
                    roleComboBox.setSelectedItem(role);
                }
            }
        });
    }

    private void clearFields() {
        idTxt.setText("");
        nameTxt.setText("");
        passTxt.setText("");
        phoneTxt.setText("");
        emailTxt.setText("");
        roleComboBox.setSelectedIndex(0); // Reset to default role
    }

    private void switchToPanel(String panelName) {
        if (parentFrame == null) {
            JOptionPane.showMessageDialog(this, 
                "Parent frame not set. Cannot switch panels.");
            return;
        }

        // Prevent infinite recursion
        if (panelName.equalsIgnoreCase("user") && this instanceof UserPanel) {
            return;
        }

        // Remove current panel
        parentFrame.getContentPane().removeAll();

        // Create and add the new panel based on the panelName
        JPanel newPanel;
        switch (panelName.toLowerCase()) {
            case "delivery":
                newPanel = new DeliveryPanel(parentFrame);
                break;
            case "commond":
                newPanel = new Commandpanel(parentFrame);
                break;
            case "customer":
                newPanel = new customerspanel(parentFrame);
                break;
            case "user":
            default:
                newPanel = new UserPanel(parentFrame);
                break;
        }

        parentFrame.add(newPanel);
        parentFrame.revalidate();
        parentFrame.repaint();
    }

    // Placeholder panel classes
    private void switchToPanel1(String panelName) {
        if (parentFrame == null) {
            JOptionPane.showMessageDialog(this, 
                "Parent frame not set. Cannot switch panels.");
            return;
        }

        // Prevent infinite recursion
        if (panelName.equalsIgnoreCase("user") && this instanceof UserPanel) {
            return;
        }

        // Remove current panel
        parentFrame.getContentPane().removeAll();

        // Create and add the new panel based on the panelName
        JPanel newPanel;
        switch (panelName.toLowerCase()) {
            case "delivery":
                newPanel = new DeliveryPanel(parentFrame);
                break;
            case "commond":
                newPanel = new Commandpanel(parentFrame);
                break;
            case "customer":
                newPanel = new customerspanel(parentFrame);
                break;
            case "user":
            default:
                newPanel = new UserPanel(parentFrame);
                break;
        }

        parentFrame.add(newPanel);
        parentFrame.revalidate();
        parentFrame.repaint();
    }
    public static void main(String[] args) {
        JFrame frame = new JFrame("=Delivery Management System=");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.add(new UserPanel(frame));
        frame.setVisible(true);
    }
}