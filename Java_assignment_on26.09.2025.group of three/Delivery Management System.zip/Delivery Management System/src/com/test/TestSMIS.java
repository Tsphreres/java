//Group 12:deliver System 
//Twizeyimana onesphore 223008132
//Murekatete kellen 223008892
//Munezero enock 223024831

package com.test;

import com.form.LoginForm;

public class TestSMIS {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		LoginForm lgnfrm= new LoginForm();

	}

}
